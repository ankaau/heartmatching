    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Know Me is a portfolio script where you can show your skills. This is a lite-version.">
    <meta name="author" content="Nirmalya Ghosh">
    <meta itemprop="name" content="Know Me - The PHP portfolio script"/>
    <meta itemprop="description" content=" Know Me is a portfolio script where you can show your skills. This is a lite-version."/>
    <meta name="twitter:site" content="http://www.infismash.com/demos/KnowMe/"/>
    <meta name="twitter:title" content="Know Me is a portfolio script where you can show your skills. This is a lite-version.">
    <meta name="twitter:description" content=" Infismash delivers the best tutorials on Photoshop, webdesign recipes, inspirations and articles on how to make yourself a better designer."/>
    <meta name="twitter:creator" content="Nirmalya Ghosh"/>
    <meta name="twitter:domain" content="http://www.infismash.com/demos/KnowMe/"/>
    <meta property="og:type" content="website"/> 
    <meta property="og:title" content="Know Me - The PHP portfolio script"/>
    <meta property="og:description" content="Know Me is a portfolio script where you can show your skills. This is a lite-version."/>
    <meta property="og:url" content="http://www.infismash.com/demos/KnowMe/"/>
    <meta property="og:site_name" content="Infismash - Creativity that inspires you"/>
    <meta property="og:see_also" content="http://www.infismash.com"/>