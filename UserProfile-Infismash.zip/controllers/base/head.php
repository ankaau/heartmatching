    <?php include 'controllers/base/meta-tags.php' ?>

    <title>Infismash - Creativity that inspires you</title>

    <?php include 'controllers/base/javascript.php' ?>
    <?php include 'controllers/base/css.php' ?>

    <?php include 'controllers/base/font.php' ?>
